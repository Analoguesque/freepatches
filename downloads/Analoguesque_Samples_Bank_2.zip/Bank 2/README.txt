----------------------------------------------------------------------------------------------------------------------------------
All samples are copyright(c) 2001 Ian Wilson.  All presets/patches are copyright(c) 2016 Ian Wilson. They are provided free to
use, but cannot be sold under any circumstances (for profit, loss, or break-even) without the express permission of the copyright
owner, Ian Wilson (thewilsonsusa@gmail.com).
----------------------------------------------------------------------------------------------------------------------------------

WARNING
A) Transmitting the samples will overwrite existing samples on your Sledge. Do so at your own risk.
   The software does not provide an option to retain the existing samples on the Sledge, or transmit them to your computer for 
   backup, so you will lose whatever samples are in the Sledge.
B) Transmitting the Presets/Patches as-is will overwrite existing patches in locations 800-865 (Pack 1) or 800-842 (Pack 2) on 
   the Sledge. Move them around within Sledge SoundMapper if you want them to occupy a different set of patch locations on
   the Sledge.

SETTING UP THE SAMPLE PACK

1) Unzipping the file will extract it to a folder called "Bank <x>", containing all the samples, presets for
   Sledge SoundMapper, and the XML file for Sledge Spectre (<x> is either 1 or 2 depending on which bank you unzip).
2) Plug your Sledge into the Computer
3) Launch the SledgeSpectre application and load the XML file. Setup the MIDI connection to the Sledge and transmit the 
   samples. It should take a few minutes.
4) Your Sledge will indicate if it is successful.  Exit the SledgeSpectre application and turn the Sledge off and back on again.
5) Launch the Sledge SoundMapper application and select the Sledge for MIDI IN and OUT. Load the .SYX file from the folder
   and transmit the patches to the Sledge.
6) Assuming there are no issues and that you transmitted without changing anything, patches 800-865 (Bank 1) and 800-842 
   (Bank 2) will reference the new samples.


BACKGROUND TO THE SAMPLES
The samples were extracted from banks created for E-Mu samplers (EIV, Emulator X, and SoundFont-compatible soundcards). 
Unfortunately the sample extract program did not pull all samples so this is a very small collection of what was in the original 
banks, which in total had more than 1,000 patches and 500 drum sounds. There may be some sounds duplicxated between banks 1 and 2,
and some samples sound quite similar. This is unfortunate for the Sledge but on the E-Mu Esynth these samples are quite different 
when moving the loop points around, which is not possible on the Sledge.

The banks were originally designed to provide samplers, and specifically E-Mu samplers, with FM sounds and various analog-style
waveforms. The waveforms were generated using custom software based around 4-op FM synthesis, with multiple custom algorithms 
for modifying waveforms, and a resonant filter. In order to generate sounds that would loop and spread across the keyboard well, 
the software was designed to fade to simple waveforms at a fixed amplitude with no shifting or FX. Additionally, it could 
auto-generate the waveforms at pitches A1, A2, A3, A4, and A5. This made it very easy to generate samples that could loop perfectly 
and spread across the keyboard as multisamples from pitch A1 through A5. Many of the samnples have FM attack transients, so they 
are distinctively FM. However the E-Mu samplers could play back samples starting at any point in the waveform, so you could get 
many different sounds out of a single sample by shifting the playback start point. You could even remove the attack of the 
original sample altogether by shifting the start point past the complex attack. Additionally, the loop start can be shifted on 
the E-Mu samplers, so you were not tied to the original loop point. Since these waveforms faded from complex to simple sounds 
(close to a sine wave), and they were designed to loop easily, you could vary the complexity simply by adjusting where the loop 
point started. ie. With a simple sound that fades from a Saw to a Sine, you could move the loop start point into the Saw range 
or the Sine range of the waveform (or inbetween), giving you one or the other. This stretches the usefullness of a waveform 
beyond expectation and turns a single sample into a multitude of patches that sound completely different. It's similar to the 
"Variation" buttons on modern synths like the Roland System 8, which provide variations of the original waveform just by turning 
a knob.  The below (somewhat humerous now) descriptions were taken from my original Analoguesque.com website that had these 
samples for sale.
