----------------------------------------------------------------------------------------------------------------------------------
NOTICE

All banks, samples, and presets are copyright(c) 2001-2004 Ian Wilson, unless otherwise noted. They are provided free to use, but
cannot be sold under any circumstances (for profit, loss, or break-even) without the express permission of the copyright 
owner, Ian Wilson (thewilsonsusa@gmail.com).
----------------------------------------------------------------------------------------------------------------------------------

FORWARD
These banks were originally designed to provide samplers, and specifically E-Mu samplers, with FM sounds and various analog-style
waveforms. The waveforms were generated using custom software that output waveforms based on 4-op FM synthesis, with multiple
custom algorithms for modifying the waves, and a resonant filter. In order to generate sounds that would loop well and spread 
across the keyboard, the software was designed to fade to simple waveforms at a fixed amplitude with no shifting or FX.
Additionally, it could auto-generate the waveforms at pitchs A1, A2, A3, A4,and A5. This made it very easy to generate waveforms
that could loop perfectly and spread across the keyboard as multisamples using pitches A1 through A5. Many of the samples have
FM attack transients, so they are distinctively FM. However the E-Mu sampler could play back samples starting at any point in
the waveform, so you could get many different sounds out of a single sample by shifting the start point of playback. You could
even remove the attack of the original sample altogether by shifting the start point past the complex attack. Additionally, the 
loop start can be shifted on the E-Mu samplers, so you were not tied to the original loop point. Since these waveforms faded from
complex to simple sounds (close to a sine wave), and they were designed to loop easily, you could vary the complexity simply by
adjusting where the loop point started. ie. With a simple sound that fades from a Saw to a Sine, you could move the loop start
point into the Saw range or the Sine range of the waveform (or inbetween), giving you one or the other. This stretches the
usefullness of a waveform beyond expectation and turns a single sample into a multitude of patches that sound completely
different. It's almost like using the "Variation" buttons on modern synths like the Roland System 8, which provide variations
on the original waveform just by turning a knob. The Emulator X banks were converted from EOS (E-Mu E4) banks and SoundFont
banks and then  tweaked in Emulator X.  One bank was done natively on the Emulator X software, so there is some overlap in the
sounds. Some of the banks appear to have changed a little between Emulator X and Emulator X3, so they are not exact. Additionally,
the original banks were done without FX because, at the time using Emulator X, the FX were built into the hardware so I felt it 
better to leave them off and let people add their own FX.  I did start playing around with this in X3 but I have neither the time 
nor the inclination to edit about 700+ patches to add FX.  Maybe some kind soul could do this and send it back to me :).  The 
below (somewhat humerous now) descriptions were taken from the original Analoguesque.com website that had these samples for sale.


--------------------------------------------------------
EX Traanz (EXB).exb - Traanz
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2004 Ian Wilson

Description
Emulator X Original
This bank has 128 presets of digital and analog emulations. It carries Analoguesque's tradition of emulating other synths using 
samplers, so you'll get the usual complement of phatt digital and analog sounds, with many geared towards trance enthusiasts. Not 
only trance musicians will use this bank - There's a host of sounds in here that can be used just about anywhere, especially 
given the 14 extra controllers available to tweak them live. If you're looking for some heavy bass and lead sounds, this is packed 
with them. It has pads thrown in because they are essential for trance, but the emphasis is definitely on bass and lead sounds.

--------------------------------------------------------
EX Analog Dreams (E4B).exb - Analog Dreams
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from EOS
This bank has 66 presets of phatt analog and digital sounds to sink your teeth into. Seering leads, thumping basses, mega 
sweeps, floating pads, and much, much more. All presets are designed on an Esynth keyboard and have been tweaked for Emulator X, 
so they take full advantage of assignable controllers while digging deep into Emulator X's superior processing power and filters. 
The waveforms in these banks are generated using our proprietary in-house software so the sounds created are very unique, and 
retain a familiar analog feel to them. What's more, they are all in pristine 16-bit, 44.1Khz quality, and digital generation 
leaves them clear of any distortions due to noise or other sampling anomalies.


--------------------------------------------------------
EX Vintage Vortex (E4B).exb - Vintage Vortex
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from EOS
Another 66 presets - The second installment of vintage emulations is an extension of the Analog Dreams genre, and here you will 
find even more impressive analog and digital presets - a perfect compliment to Analog Dreams. There is not much more to be 
said about these sounds other than what has already been described for Analog Dreams. You get more of the same phatt, pulsating 
sounds!


--------------------------------------------------------
EX Vintage Plastique (E4B).exb - Vintage Plastique
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from EOS
This adds another dimension to the emulations with another 66 amazing vintage presets. This pumped the EOS operating system 
to the max, but has been tweaked even further to push Emulator X to it's limits! This is just more phatt analog and digital 
textures to play with!


--------------------------------------------------------
EX Vintage Synth 2001 (SF2).exb - Vintage Synth 2001
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from SoundFont
If you're into Dark Wave, Trance, Techno, Dance, Electronica, Synthpop, and other electronic music, Vintage Synth 2001 is a 
necessity for your collection! Growling, thumping, and pulsating basses. Screaming leads. Soaring pads. Gritty synths. They're 
all in here. If the words sweep, grunge, dirty, gritty, screaming, resonating, pounding, and stomping mean anything to you, 
then this is something you must have! The emphasis is on samples generated using proprietary, in-house software synths, and 
building instruments from small pieces into a huge crescendo of sound. You're looking at some very unique and highly evolving 
textures. In total, Vintage Synth 2001 has 128, phatt, mind-bending patches to sink your teeth into - A huge sonic palette to 
immerse yourself in!


--------------------------------------------------------
EX Digital Bliss (SF2).exb - Digital Bliss
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from SoundFont
Digital Bliss follows in the very ample footsteps of Vintage Synth 2001, but this time with an emphasis on vintage digital 
and hybrid synths rather than just analog. However, this is not to say that all the sounds are digital. It contains a full 
complement of 128 patches, concentrating on digital pads, leads, basses, and FX, but still with some analog patches thrown 
in for good measure because you can't get enough of those! Don't mistake digital to mean thin. This bank has enough low-end 
ballz to knock an elephant on its back! There is extreme playability, which brings a live feel to your music and allows 
playback just like old analog synths. There is no description for these sounds!


--------------------------------------------------------
EX Cheezoids (SF2).exb - Cheezoids
--------------------------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Converted from SoundFont
This is the ultimate Digital emulation SoundFont� Bank, and follows a path from 1981 to 1984, when analog was dying and 
the dawn of cheap digital had arrived. Did you miss out on the pioneering years of synth music?� Did you miss out on Hi-NRG, 
Eurobeat, or Italo Disco? Do you remember Trans-X, Tapps, The Flirts, People Like Us, Lime, or Fancy? Do you remember Speak 
and Spell from Depeche Mode, Yazoo (Yaz), Blancmange, OMD, and Dare from The Human League? Well this is your chance to get 
to grips with the type of sounds they were using during those pioneering synth years. A solid 128 patches of the coolest 
retro digital sounds around, and all with the usual Analoguesque quality.�This bank is predominantly Pads and Leads, but 
still with enough rocking bass thrown in to keep it mixed.
