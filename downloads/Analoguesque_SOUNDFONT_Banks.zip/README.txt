----------------------------------------------------------------------------------------------------------------------------------
NOTICE

All banks, samples, and presets are copyright(c) 2001 Ian Wilson, unless otherwise noted. They are provided free to use, but
cannot be sold under any circumstances (for profit, loss, or break-even) without the express permission of the copyright 
owner, Ian Wilson (thewilsonsusa@gmail.com).
----------------------------------------------------------------------------------------------------------------------------------


FORWARD
These banks were originally designed to provide samplers, and specifically E-Mu samplers, with FM sounds and various analog-style
waveforms. The waveforms were generated using custom software for generating waveforms based on 4-op FM synthesis, with multiple
custom algorithms for modifying the waves, and a resonant filter. In order to generate sounds that would loop well and spread 
across the keyboard, the software was designed to fade to simple waveforms at a fixed amplitude with no shifting or FX.
Additionally, it could auto-generate the waveforms at pitchs A1, A2, A3, A4,and A5. This made it very easy to generate waveforms
that could loop perfectly and spread across the keyboard as multisamples using pitches A1 through A5. Many of the samnples have
FM attack transients, so they are distinctively FM. However the E-Mu samplers could play back samples starting at any point in
the waveform, so you could get many different sounds out of a single sample by shifting the start point of playback. You could
even remove the attack of the original sample altogether by shifting the start point past the complex attack. Additionally, the 
loop start can be shifted on the E-Mu samplers, so you were not tied to the original loop point. Since these waveforms faded from
complex to simple sounds (close to a sine wave), and they were designed to loop easily, you could vary the complexity simply by
adjusting where the loop point started. ie. With a simple sound that fades from a Saw to a Sine, you could move the loop start
point into the Saw range or the Sine range of the waveform (or inbetween), giving you one or the other. This stretches the
usefullness of a waveform beyond expectation and turns a single sample into a multitude of patches that sound completely
different. It's almost like using the "Variation" buttons on modern synths like the Roland System 8, which provide variations
on the original waveform just by turning a knob.  The below descriptions were taken from the original Analoguesque.com
website that had these samples for sale.


----------------------------------------
czoids.sf2 - Cheezoids
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
This is the ultimate Digital emulation SoundFont� Bank, and follows a path from 1981 to 1984, when analog was dying and the dawn 
of cheap digital had arrived. Did you miss out on the pioneering years of synth music?� Did you miss out on Hi-NRG, Eurobeat, or 
Italo Disco? Do you remember Trans-X, Tapps, The Flirts, People Like Us, Lime, or Fancy? Do you remember Speak and Spell from 
Depeche Mode, Yazoo (Yaz), Blancmange, OMD, and Dare from The Human League? Well this is your chance to get to grips with the 
type of sounds they were using during those pioneering synth years. A solid 128 patches of the coolest retro digital sounds 
around, and all with the usual Analoguesque quality.�This SoundFont is predominantly Pads and Leads, but still with enough 
rocking bass thrown in to keep it mixed.


----------------------------------------
dbliss.sf2 - Digital Bliss
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Digital Bliss follows in the very ample footsteps of Vintage Synth 2001, but this time with an emphasis on vintage digital 
and hybrid synths rather than just analog. However, this is not to say that all the sounds are digital. It contains a full 
complement of 128 patches, concentrating on digital pads, leads, basses, and FX, but still with some analog patches thrown 
in for good measure because you can't get enough of those! Don't mistake digital to mean thin. This SoundFont� has enough 
low-end ballz to knock an elephant on its back! Several velocity-sensitive patches are also included, each responding to up 
to 7 layers of velocity. This gives you extremely expressive playability, which brings a live feel to your music and allows 
playback just like old analog synths.


----------------------------------------
vd2001.sf2 - Vintage Drums 2001
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Being the sister of Vintage Synth 2001, Vintage Drums 2001 will keep your ears tuned in for months!� Obligatory TR909, 
TR808, and CR-78 emulations are included, as well as many other drum machines, real and imagined! Remember that since these 
are designed from the ground up rather than sampled from the original instruments, you do not have anything like this in 
your collection. They are very unique sounds with a flavour of the original drumboxes. Some TR909 kicks are heavier than the�
original TR909. Some TR808 snares are snappier than the original TR808. In all cases, you get something unique and you get 
a lot of it. Favorites include the two huge analog kits, with around 6 octaves of percussion each, as well as the 
clean-sounding TR and CR kits, and the amazingly versatile FM Percussion kit! The list is extensive and includes over 500 
drum sounds! A lot of people have raved about the kits in this bank and at this price you are getting a serious bargain.
Vintage Drums 2001 is an absolutely massive SoundFont� with a wealth of phatt, thumping, grungy, and cheesy sounds to 
satisfy even the most ardent vintage synth fan. There are a lot of sounds to choose from in this bank!


----------------------------------------
vs2001.sf2 - Vintage Synth 2001
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
If you're into Dark Wave, Trance, Techno, Dance, Electronica, Synthpop, and other electronic music, Vintage Synth 2001 
is a necessity for your collection! Growling, thumping, and pulsating basses. Screaming leads. Soaring pads. Gritty synths. 
They're all in here. If the words sweep, grunge, dirty, gritty, screaming, resonating, pounding, and stomping mean 
anything to you, then this is something you must have! The emphasis is on samples generated using proprietary, in-house 
software synths, and building instruments from small pieces into a huge crescendo of sound. You're looking at some very 
unique and highly evolving textures.


----------------------------------------
vdw20.sf2 - Vintage Dreams Waves 2.1.
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
This freeware SoundFont� Bank from one of the principal Analoguesque designers has been around for several years already 
(1996), and is still (along with Vintage Dreams Drums) consistently one of the most downloaded on the web. At only 117Kb 
uncompressed, it contains a full 128 presets in the instrument section. The 8 drum kits in the percussion section have 
been removed and can be found separately as Vintage Dreams Drums. Although now hopelessly outdated and showing it's age, 
this SoundFont� Bank has� been compared to 4Mb, 8Mb, and even 16Mb SoundFont� Banks by some users!� I'm not sure we would 
go so far as to compare it to 16Mb, but it certainly is worth a lot more than it's 117Kb would suggest. Is it worth the 
download? Sure. Is it anything like the commercial SoundFont� Banks? No, the quality is nowhere near our commercial 
SoundFont Banks, although the principles are very similar.


----------------------------------------
vdd.sf2 - Vintage Dreams Drums
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
This SoundFont� Bank is simply the drum kit presets from the original Vintage Dreams Waves 2.0, which were removed f
or version 2.1 above. They are no longer available in Vintage Dreams Waves 2.1. The drum kits have been inserted into 
both the percussion and instrument preset sections, which allows their use on all midi channels. You can use hi-hats 
from one kit, combined with a snare from another kit, and a kick from yet another kit - You simply assign different 
kits to different midi channels. This SoundFont� Bank is also showing it's age and cannot compare to it's newer 
siblings, but it is still quite useful in many situations, such as trance, electronica ... etc. It contains emulated 
8 drum kits, including:
� TR101 - Imaginary TR set from a non existent Roland.
� CR-78 - The old trusty blips and blobs of the Roland CR-78.
� TR808 - Staple diet of Hip Hop and dance tunes..
� TR909 - Staple diet of dance, trance, electronica, and anything related.
� Analog - A Whole slew of analog-type percussion and drums.
� Kraftwerk - A kit designed around the early sound techno pioneers, Kraftwerk.
� Electronic - Simmons-like percussion and drums
� TR808 II - A second, more polished set of TR808 emulations.


----------------------------------------
vocaldrumz.sf2 - Vocal Drumz
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Here is a set of vocalized drums, comprising several snares, kicks, toms, hi-hats and cymbals, and a few other sounds. 
If you're looking for something really whacky, give this a try.
