----------------------------------------------------------------------------------------------------------------------------------
NOTICE

All banks, samples, and presets are copyright(c) 2001 Ian Wilson, unless otherwise noted. They are provided free to use, and
cannot be sold under any circumstances (for profit, loss, or break-even) without the express permission of the copyright 
owner, Ian Wilson (thewilsonsusa@gmail.com).
----------------------------------------------------------------------------------------------------------------------------------

FORWARD
These banks were originally designed to provide samplers, and specifically E-Mu samplers, with FM sounds and various analog-style
waveforms. The waveforms were generated using custom software for generating waveforms based on 4-op FM synthesis, with multiple
custom algorithms for modifying the waves, and a resonant filter. In order to generate sounds that would loop well and spread 
across the keyboard, the software was designed to fade to simple waveforms at a fixed amplitude with no shifting or FX.
Additionally, it could auto-generate the waveforms at pitchs A1, A2, A3, A4,and A5. This made it very easy to generate waveforms
that could loop perfectly and spread across the keyboard as multisamples using pitches A1 through A5. Many of the samnples have
FM attack transients, so they are distinctively FM. However the E-Mu samplers could play back samples starting at any point in
the waveform, so you could get many different sounds out of a single sample by shifting the start point of playback. You could
even remove the attack of the original sample altogether by shifting the start point past the complex attack. Additionally, the 
loop start can be shifted on the E-Mu samplers, so you were not tied to the original loop point. Since these waveforms faded from
complex to simple sounds (close to a sine wave), and they were designed to loop easily, you could vary the complexity simply by
adjusting where the loop point started. ie. With a simple sound that fades from a Saw to a Sine, you could move the loop start
point into the Saw range or the Sine range of the waveform (or inbetween), giving you one or the other. This stretches the
usefullness of a waveform beyond expectation and turns a single sample into a multitude of patches that sound completely
different. It's almost like using the "Variation" buttons on modern synths like the Roland System 8, which provide variations
on the original waveform just by turning a knob.  The below (somewhat humerous now) descriptions were taken from the original 
Analoguesque.com website that had these samples for sale.  They are quite dated now, but definitely provide a useful sonic 
palette that's a little different from the norm.


----------------------------------------
EOS001.E4B - Analog Dreams
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
This bank has 66 presets of phatt analog sounds to sink your teeth into. Seering leads, thumping basses, mega sweeps, floating 
pads, and much, much more. All presets are designed on an Esynth keyboard and take full advantage of all the assignable 
controllers and sliders, while digging deep into Emu�'s superior processing power and filters. As in our SoundFont Bank 
collections, the waveforms in these banks are generated using our proprietary in-house software, so the sounds created are 
very unique, although retaining a familiar analog feel to them. What's more, they are all in pristine 16-bit, 44.1Khz quality, 
and digital generation leaves them clear of any distortions due to noise or other sampling anomalies.

----------------------------------------
EOS002.E4B - Vintage Vortex
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
The second installment of 66 presets of vintage emulations is an extension of the Analog Dreams genre, and here you will find 
even more impressive analog presets - a perfect compliment to Analog Dreams. There is not much more to be said about these 
sounds other than what has already been described for Analog Dreams. You get more of the same phatt, pulsating sounds!

----------------------------------------
EOS003.E4B - Vintage Plastique
----------------------------------------
Designed by Analoguesque Sound Designs (Ian Wilson)
Copyright (c) 2001 Ian Wilson

Description
Third installment of vintage emulations with another 66 amazing  presets. This final in the triple-set of vintage analog 
emulations pumps the EOS operating system to the max! More phatt analog stuff!


----------------------------------------------------------------------------------------------------------------------------------
These banks can all be saved onto a 3� inch floppy disk and then loaded into your EOS synth. This is the only way you can get the 
E4B format into your Emu� sampler. The E4B format used for the save is compatible with all Emu� equipment running the EOS 
operating system. What is E4B format? It is a DOS-compatible format which is saved from the ESynth onto any DOS-formatted disk. 
Although extremely slow and agonizing, the E4B format is easy to work with, transfer, and download. It takes some time to load the
sounds into your ESynth from floppy, but once they're loaded you can dump them to your ESynth's internal HDD.

Loading the E4B banks into your Emu requires the following:
1. Your Emu must have a working 3� inch floppy drive and be able to accept E4B format files.
2. You must be able to format a DOS floppy. 
----------------------------------------------------------------------------------------------------------------------------------