Copyright (c) 2024-2026 Ian Wilson, Analoguesque Sound Designs
Not for resale in any capacity

http://analoguesque.x10host.com/Analoguesque_HS_Presets_Free_ALL_update.html


-------------
Color-Coding
-------------
Blue: Lead
Red: Bass
Green: Pad
White: FX
Yellow: Organ

-------------------------------------------------
BANK A - Analoguesque Bread and Butter I		
-------------------------------------------------
#	Patch Name      	Category
001	Fairlight ARR1  	Lead
002	Save a Prayer   	Pad
003	DM JCGE         	Lead
004	Da Funk I       	Lead
005	Cars Let's Go   	Lead
006	VL-1 Fantasy    	Pad
007	Red Carpet Mass 	Lead
008	Black Cel Bell 1	Pad
009	Black Cel Bell 2	Pad
010	Black Cel Lead 1	Lead
011	Black Cel Lead 2	Lead
012	DM Nodisco      	Lead
013	OB Sunrise      	Pad
014	Sqyquake        	Pad
015	DX7 Ebass 1     	Bass
016	Rez Blip        	Pad
017	Grungo Crunch   	Lead
018	OPL3 FM Pad 1   	Pad
019	CZ Sweep        	Pad
020	Bowp Bass       	Bass
021	80s Poly Strings	Pad
022	Tinkly Bonk Digi	Pad
023	Frog Bass       	Bass
024	1984 Poly       	Lead
025	Swirling Strings	Pad
026	Sample Smash    	Fx
027	Machines        	Fx
028	80's Turbo Bass 	Bass
029	FM Percussion   	Fx
030	Running Up Hill 	Lead
031	Red Strings     	Pad
032	V. Clarke Bass  	Bass
033	Fizzpop         	Pad
034	Huge Bells      	Pad
035	Skreem          	Fx
036	Juno Hoover     	Pad
037	KillJoy         	Pad
038	OPL3 FM Pad 2   	Pad
039	Roland Moon Man 	Pad
040	Pulse Strings   	Pad
041	Bulbous Bass    	Bass
042	Skinny Strings  	Pad
043	Majesty         	Pad
044	Jo'burg Strings 	Pad
045	Rubbery Bass    	Bass
046	Ghost Machine   	Pad
047	Ballzy Bowp Bass	Bass
048	Headcase        	Bass
049	Obsession       	Pad
050	Jupiter 8.5 Bass	Bass
051	Dirty Wow       	Bass
052	Voices          	Lead
053	Pluckey         	Lead
054	Roly-Poly       	Pad
055	Space Strings   	Pad
056	Blu Bass        	Bass
057	Exciter         	Bass
058	Eraser          	Pad
059	Electro Bass    	Bass
060	Bubble Blip     	Bass
061	Karoo Sand Lead 	Lead
062	Metal 'Splosion 	Fx
063	FM Horizon      	Pad
064	HL Dirty 700S   	Lead
065	Tin Roof Bass   	Bass
066	Cutlass         	Bass
067	D50 Breathless  	Pad
068	Moonscapes      	Pad
069	Bubbles         	Lead
070	Simple Minds Pik	Lead
071	D50 Angel Bells 	Pad
072	DX7 Slap Bass 1 	Bass
073	Hot Strings     	Pad
074	Run Bass        	Bass
075	Viper Strings   	Pad
076	System 100 Grit 	Lead
077	Pass Me By      	Pad
078	Wow Filter Sweep	Pad
079	Space War       	Fx
080	Beez            	Pad
081	Royal Crown     	Pad
082	Soaring         	Pad
083	Yazoo Seq Bass  	Bass
084	Dream Strings   	Pad
085	Voer-Voer       	Pad
086	Sky Strings     	Pad
087	Landscape       	Pad
088	Ride Bass       	Bass
089	Metal Wow       	Lead
090	Shwish          	Pad
091	Screaming Blips 	Pad
092	Portrait        	Pad
093	Faux Strings    	Pad
094	Halo            	Pad
095	Viper Vox       	Pad
096	Faux Violin     	Lead
097	Purgatory       	Lead
098	Perspex         	Pad
099	Bubble Blip 2   	Pad
100	Hot Mess        	Lead
101	Dirty Bass-tard 	Bass
102	Janky Bells     	Pad
103	Angels          	Pad
104	Whoa            	Pad
105	Beelzebub       	Pad
106	Blip Bass       	Bass
107	Hells Bells     	Pad
108	Ice Echos       	Pad
109	Dreamy 2        	Pad
110	Choir Strings   	Pad
111	SoundBlaster FM 	Pad
112	Drakensberg Howl	Lead
113	2-Tone Tommy    	Lead
114	Vibes 2         	Lead
115	Titanic Modular 	Bass
116	Midnight        	Lead
117	Strip Pluck     	Lead
118	Veep Lead       	Lead
119	Wheezy          	Pad
120	Unpredictable   	Bass
121	Wind Up         	Lead
122	Aye Voices      	Pad
123	Noon            	Pad
124	HL Dare Bass    	Bass
125	System 100M Grit	Bass
126	Magistrate      	Pad
127	Classic Moog    	Bass
128	Stunted Bass    	Bass



-------------------------------------------------
BANK B - Analoguesque Bread and Butter II			
-------------------------------------------------
#	Patch Name      	Category
001	BSII Bass       	Bass
002	E-Mu Stack      	Lead
003	Hydra DX E-Piano	Lead
004	Animated        	Lead
005	JMJ Digi Harp   	Lead
006	Bubbloids       	Fx
007	Rubberband Bass 	Bass
008	Squeezee        	Pad
009	Brooklyn Strings	Pad
010	OPL2 Pad        	Pad
011	Analog Old Timey	Pad
012	Round Bass      	Bass
013	Silver Strings  	Pad
014	DX7 Slap Bass 2 	Bass
015	Motherlode      	Pad
016	Alien Landscape 	Fx
017	Chorale         	Pad
018	Fizzy Strings   	Pad
019	Thunder Bass    	Bass
020	FM Glory        	Pad
021	Eastern Bells   	Pad
022	Moon Wow        	Pad
023	Ripping Bass    	Bass
024	Magenta Brass   	Pad
025	Monk Caves      	Lead
026	Cola Bottle     	Pad
027	Saturn Static   	Fx
028	Fairlight ARR2  	Pad
029	FM Dulci        	Pad
030	Sulphuric Arp   	Arp
031	FilterSweep Bass	Bass
032	Bop Bass        	Bass
033	Faery Dust      	Pad
034	Roland Fat Bass 	Bass
035	Medusa Breath   	Pad
036	The Flood       	Pad
037	Digi Warble     	Pad
038	Bouncy Bass     	Bass
039	HiRise          	Lead
040	FM Bell         	Pad
041	Hyper Moog      	Bass
042	Crusher         	Lead
043	Bloodline       	Pad
044	Slapback        	Bass
045	Silica          	Pad
046	Salvation       	Pad
047	Wild Ride       	Lead
048	Super Strings   	Pad
049	Radio Relief    	Lead
050	Sprite Wobble   	Lead
051	E-Mu Valhala    	Lead
052	Drakensberg Str 	Pad
053	Vibes           	Lead
054	Rough Cut       	Lead
055	Ballzy Bass     	Bass
056	Pluck Strings   	Pad
057	FM Bowp         	Bass
058	Haunting        	Lead
059	Plainsong String	Pad
060	TX81Z Lately    	Bass
061	DX Big Bells    	Lead
062	FM Pluck        	Lead
063	Breathtaking    	Pad
064	The Machine     	Fx
065	HP Strings      	Pad
066	Hi Q            	Fx
067	Kick (Analog)   	Fx
068	Kick (Filter)   	Fx
069	Snare 1 (909)   	Fx
070	Snare 2 (Analog)	Fx
071	Snare 3 (Analog)	Fx
072	Slap Snare (HS) 	Fx
073	Claps (Analog)  	Fx
074	Hi Hats (Analog)	Fx
075	Shakers (Analog)	Fx
076	Toms (Analog)   	Fx
077	Cowbell (808)   	Fx
078	Clave (Analog)  	Fx
079	DM Blips        	Pad
080	HL Travelogue   	Lead
081	Thin Bass       	Bass
082	Mjolnir Thunder 	Fx
083	Black Strings   	Pad
084	Whump Bass      	Bass
085	Dreams          	Pad
086	Fake            	Lead
087	FM Swirls       	Pad
088	Chipmunk Synth  	Lead
089	Nasty FM        	Pad
090	Drone Bass      	Bass
091	Vixen           	Pad
092	Killbells       	Pad
093	SuperWow        	Pad
094	Traanz Lead     	Lead
095	E-Mu Bang       	Lead
096	Growler         	Bass
097	Yazoo Whomp Bass	Bass
098	DX7 Slap Bass 3 	Bass
099	Etherial        	Pad
100	Star Wars Chat  	Fx
101	Digitalia       	Pad
102	Saturn Drops    	Pad
103	Lunar Rise      	Pad
104	BSII Bass 2     	Bass
105	Juno Tide       	Pad
106	Transylvania    	Lead
107	Penitence Aah   	Pad
108	Rumble Bass     	Bass
109	Galaxies        	Pad
110	Modular Monsta  	Bass
111	Da Funk II      	Pad
112	Longbass Drone  	Bass
113	5th Strings     	Pad
114	Grit House      	Bass
115	FM Small Pluck  	Pad
116	Leaky Transistor	Lead
117	Venus Vox       	Pad
118	Mtn Top Brass   	Pad
119	Cream           	Pad
120	Voxy            	Pad
121	Hive Mind       	Lead
122	Subby Drone     	Bass
123	Millenial Hoover	Lead
124	Wonderland      	Pad
125	Vorlon Saws     	Lead
126	Mulcher         	Pad
127	Alpha Centauri  	Lead
128	Tinkly Bells    	Pad


-------------------------------------------------
BANK C - Analoguesque Esoteric I			
-------------------------------------------------
#	Patch Name      	Category
001	Cloud Choir     	Pad
002	Sonik Bass      	Bass
003	Fuzzball FB 1   	Lead
004	Old Synth Bass  	Bass
005	Thunderous Bass 	Bass
006	Secret Strings  	Pad
007	Thin Bass Sweep 	Bass
008	VL-1 Steroids   	Pad
009	Trance Sine Lead	Lead
010	Roland Stack Str	Pad
011	Buckingham Brass	Lead
012	Darude Lead     	Lead
013	Blue Strings    	Pad
014	OPL2 Bass II    	Bass
015	Hydra Piano Pluk	Lead
016	Rum Runner Bass 	Bass
017	Silver Choir    	Pad
018	Wow Sweep Bass  	Bass
019	Faroff Lands    	Lead
020	Faerie Choir    	Pad
021	Your Thumpiness 	Bass
022	80s Italo Brass 	Lead
023	Vorlon Strings  	Pad
024	Fuzzball FB 2   	Lead
025	Heimdall Lead   	Lead
026	Thin Strips     	Pad
027	Screaming Saws  	Lead
028	Distort Me      	Lead
029	Dragon Breath   	Pad
030	Saturn Breath   	Lead
031	Buzz Wow        	Pad
032	Slipstream Lead 	Lead
033	Synth Boys      	Lead
034	Scaredy Cat     	Pad
035	Galaxy Pad      	Pad
036	Classic Analog  	Bass
037	Marshmallow Pad 	Pad
038	Galaxy Wars     	Fx
039	Shadow Voices   	Pad
040	Nettles         	Pad
041	Blippety Bloops 	Pad
042	Lead Grinder    	Lead
043	Massive Bass    	Bass
044	Salty Lead      	Lead
045	Fruity Flute    	Lead
046	Plinky Saws     	Pad
047	Skinny Whisps   	Pad
048	Organic Pattern 	Organ
049	Revolving Pad   	Pad
050	Crying Glass    	Pad
051	Stringalicious  	Pad
052	Distant Orca    	Pad
053	Gorilla Whomp   	Pad
054	Whip Strings    	Pad
055	Crystaline Block	Lead
056	Computer World  	Fx
057	Scare Tactics   	Pad
058	Broken Flute    	Lead
059	Metallic Orch   	Lead
060	Loki Strings    	Pad
061	Whipping Lead   	Lead
062	Pleides Gong    	Pad
063	Hydra Lead      	Lead
064	Pleides Caves   	Pad
065	Saturn Whistle  	Pad
066	Clangorous Lead 	Lead
067	Bubblegum Swirl 	Pad
068	OB Stringee     	Pad
069	D50 Fake DX7    	Lead
070	Whispy Bass Pad 	Bass
071	Boring Lead     	Lead
072	Air Step Lead   	Lead
073	Noisy Organ     	Organ
074	Guitar Pluck    	Lead
075	Pandora Wretch  	Fx
076	Rue de Strings  	Pad
077	Breezy Lead     	Lead
078	Stepped BassPad 	Bass
079	Soulful Pad     	Pad
080	Machine Lead    	Lead
081	Another 80s Poly	Lead
082	Sunbeam Strings 	Pad
083	Wonky Lead      	Lead
084	Star Saws       	Pad
085	Gulch Lead      	Lead
086	Odinson Strings 	Pad
087	Serious Strings 	Pad
088	Centauri Pad    	Pad
089	Saturn Phazer   	Pad
090	Demos Beams     	Pad
091	Cottage Flutes  	Lead
092	Demon Crags     	Pad
093	Faroff Lands    	Pad
094	Harsh Rider     	Lead
095	HCL Bass Blips  	Bass
096	Organ-ic        	Organ
097	Incongruency    	Pad
098	Flutterbug Pad  	Pad
099	Saltlick Saws   	Pad
100	Dirty Swell Pad 	Pad
101	AM Bellisimo    	Lead
102	Water Saws      	Lead
103	U and Me Both   	Lead
104	ConcertHall Clav	Lead
105	Singing Grinder 	Pad
106	Crunchy Synth   	Lead
107	Massive Saws    	Lead
108	Bellatious      	Pad
109	Skyquake Death  	Pad
110	Bang-a-Gong     	Pad
111	Stacked Lead    	Lead
112	Tapedeck Stretch	Pad
113	E-Mu Bell Pad   	Pad
114	Ice Blips Pad   	Pad
115	WTF Chamber     	Pad
116	D50 Glass Saws  	Pad
117	Distant Mirage  	Lead
118	Cosmos Choir    	Pad
119	Gunk Bass       	Bass
120	Erasuresque     	Lead
121	Clown Organ     	Organ
122	Industrial Pad  	Pad
123	Witch of Asgard 	Lead
124	Spud Bass       	Bass
125	Bell Whoa       	Pad
126	UFO Engine Stop 	Fx
127	Sif Warble      	Pad
128	Woody           	Lead


-------------------------------------------------
BANK D - Analoguesque Random Experiments			
-------------------------------------------------
#	Patch Name      	Category
001	Erasuresque II  	Lead
002	Gunk Bass II    	Bass
003	Metal Strings   	Pad
004	Mindwarp Bass   	Bass
005	Space Bagpipe   	Pad
006	Horror Pad      	Pad
007	Hoover Strings  	Pad
008	Industrial Pad 2	Pad
009	Broken Pad      	Pad
010	Glass Wire Pad  	Pad
011	Breezy Choir    	Pad
012	Brixton Fountain	Pad
013	FM Space Pad    	Pad
014	Orca Pad        	Pad
015	Distant 5th     	Pad
016	80s Pings       	Pad
017	Tinfoil Scream  	Pad
018	Growl           	Pad
019	Bondo Organ     	Organ
020	Organ Drone     	Organ
021	Arcade Fun      	Fx
022	Ugly Organ      	Organ
023	Distant Priest  	Pad
024	Cheap Plug      	Pad
025	Buzzy Lead      	Lead
026	4 Bit Pad       	Pad
027	Gomorah Pad     	Pad
028	6 Bit Strings   	Pad
029	Toy Piano       	Pad
030	Etherial Organ  	Organ
031	String Life     	Pad
032	Alien Farms     	Pad
033	Bowed Bell      	Pad
034	70s Lead        	Lead
035	Reedy Lead      	Lead
036	Steel Voices    	Pad
037	Faerie Birds    	Pad
038	Ella Strings    	Pad
039	Cyclops         	Pad
040	Throat Bass     	Bass
041	Digitized       	Pad
042	Digisweep       	Pad
043	Aethelston Str  	Pad
044	Growl Bowp      	Bass
045	Dirty Drone     	Pad
046	Whatnot         	Pad
047	Saturn Birds    	Pad
048	Throaty Lead    	Lead
049	Whiskey Bowp    	Bass
050	Stacked Hoover  	Lead
051	Sad Lead        	Lead
052	Melting Pad     	Pad
053	Cathedral 1     	Pad
054	Bowed Frogbass  	Bass
055	Analog World    	Pad
056	Square Seq      	Pad
057	Factory Strings 	Pad
058	Highland Lead   	Lead
059	Swirligig       	Pad
060	Majestic Ruby   	Pad
061	Majestc Emerald 	Pad
062	Hoover Squared  	Lead
063	War Bass        	Bass
064	Thick Lead      	Lead
065	FM Badboy       	Pad
066	Clowning Around 	Pad
067	Fazing Pad      	Pad
068	Planet Talkies  	Pad
069	Bottleneck      	Pad
070	Dirty Wah       	Pad
071	Bitcrunch Bells 	Pad
072	50 buck Lead    	Lead
073	Hazy Pad        	Pad
074	Back 2 Arcade   	Pad
075	Reverse Stack   	Pad
076	Eastern Drone   	Pad
077	Spikey Sweep    	Pad
078	Crunchbit Lead  	Lead
079	2 Buck Organ    	Organ
080	Sterile Flute   	Pad
081	Baby Piano      	Lead
082	Overture Strings	Pad
083	Nazal Lead      	Lead
084	PadLead         	Lead
085	OutOfSync Stack 	Pad
086	Stepped Bass    	Bass
087	Alpha Pads      	Pad
088	Moon Cresta     	Fx
089	Muted Digihorn  	Pad
090	Digi Cliff Dive 	Pad
091	Decimated Organ 	Organ
092	Big Analog Str  	Pad
093	Bloodfilter Bass	Bass
094	Resonating Organ	Organ
095	Around The World	Pad
096	Kiddie Glock    	Pad
097	Voice Rise Lead 	Lead
098	Noisy Glass     	Pad
099	Muddy Strings   	Pad
100	Angel 2 Devil   	Pad
101	Flute Pad       	Pad
102	Stepping Stones 	Pad
103	Flutesque       	Pad
104	Oblique Keys    	Lead
105	Factory Leads   	Lead
106	Easy Street     	Pad
107	Amber Glass     	Pad
108	Swirling Organic	Pad
109	Simple Saws     	Pad
110	Peeoow          	Pad
111	Digital Chug    	Pad
112	What Am I       	Pad
113	Digital Sweeps  	Pad
114	Bass Wow        	Bass
115	Static Bell Lead	Lead
116	Thick Saws      	Pad
117	Gong Bass       	Bass
118	Heaven Scent    	Pad
119	M1 Organ        	Organ
120	Synthi Swirl    	Pad
121	Casio Pluck     	Lead
122	Synth Chorale   	Pad
123	Baritone Boss   	Bass
124	Bad Plucks      	Pad
125	Flute Strings   	Pad
126	R5-D5           	Fx
127	Eastern Pluck   	Pad
128	Svelte Lead     	Lead


-------------------------------------------------
BANK E - Analoguesque Esoteric II			
-------------------------------------------------
#	Patch Name      	Category
001	Abacab          	Lead
002	1982 Bass Bump  	Bass
003	Slap Dub Bass   	Bass
004	Alpha Bass      	Bass
005	Shock Wow Bass  	Bass
006	Skinny Wail     	Lead
007	Old Model D     	Bass
008	Thor Bass       	Bass
009	Undersea Chorale	Pad
010	Pretentious Saws	Lead
011	Solina-Esque    	Pad
012	Dirty Brass     	Lead
013	Digital Glass   	Pad
014	Vocal Pad       	Pad
015	PWM Keys        	Lead
016	Etheriality     	Lead
017	E-Mu Semi-stack 	Lead
018	Sawblade Pad    	Pad
019	Glass Hallway   	Lead
020	Krull Voices    	Pad
021	MS20 Stubby Bass	Bass
022	Vorlon Vibra    	Pad
023	Planetary Voices	Pad
024	80's Stringz    	Pad
025	Cave Grind      	Pad
026	Multi Stab      	Pad
027	Organ Blues     	Organ
028	Distorted Str   	Pad
029	Goliath Bass    	Bass
030	Skreeming Lead  	Lead
031	Wandering Pad   	Pad
032	Aeroplane Pad   	Pad
033	Tweaky Pad      	Pad
034	Steel Distortion	Pad
035	D50 Bellisimo   	Pad
036	Buzzy Pad       	Pad
037	Hive Lead       	Lead
038	Digital Vinyl   	Pad
039	Feedback Pad    	Pad
040	Cavern Dropcloth	Pad
041	Sideband Lead   	Lead
042	Murmering Pad   	Pad
043	Landing Pad     	Pad
044	Breathy Organ   	Organ
045	Clambor Strings 	Pad
046	Metal Industrie 	Pad
047	Steel Glass     	Pad
048	Baby Glocken    	Pad
049	Bell Grinder    	Pad
050	Sampled Strings 	Pad
051	Crushing Keys   	Pad
052	Falling Warble  	Pad
053	Diode Drop      	Pad
054	Gargantuous     	Pad
055	Breezy Blues    	Pad
056	Funko Lead      	Lead
057	E-Mu Stack Org  	Organ
058	Trade Winds     	Pad
059	Crunchy Bells   	Pad
060	Wonky Keys      	Pad
061	Toy Box Glock   	Pad
062	Big Phatt Big   	Pad
063	Misled Pad      	Pad
064	Bomb Dropoff    	Pad
065	Clown Xylophone 	Pad
066	Big DX Bass     	Bass
067	Crushing Sweep  	Pad
068	Metallic Strings	Pad
069	Steeldrum Bonks 	Pad
070	Italo Disco Lead	Lead
071	Swellisimo      	Pad
072	Cymbolic Pad    	Pad
073	Crushing Swell  	Pad
074	Old Skool Layer 	Pad
075	Cymbolic Lead   	Lead
076	Kraftwerk Honk  	Pad
077	Circys Crazy    	Pad
078	Mass Distortion 	Pad
079	Singing Pad     	Pad
080	Swirlpool       	Pad
081	Broken Frame Seq	Pad
082	Icecapades Pad  	Pad
083	Space Blast     	Pad
084	Darude 2        	Lead
085	Solina Phaser   	Pad
086	Blob Bass       	Bass
087	Dirty Faze Pad  	Pad
088	Angel Glass Pad 	Pad
089	DCO Sweep       	Pad
090	Bass Organ      	Organ
091	Boring Lead II  	Lead
092	Gaboon Viper    	Pad
093	Crystal Zipper  	Pad
094	Quake Bass      	Bass
095	Sinewy Lead     	Lead
096	Muted Echo Pad  	Pad
097	Factory Scrape  	Pad
098	Phatt Saws      	Pad
099	Slim Digikeys   	Lead
100	Brittle Stack   	Pad
101	Humpty Swell    	Pad
102	Bog Std Chord   	Pad
103	Bog Std Chord 2 	Pad
104	Sampler Stab    	Pad
105	Behind The Wheel	Pad
106	Fairy Child     	Pad
107	Bloopy          	Pad
108	Ripple Bass     	Bass
109	Easy Swell      	Pad
110	Big Sidebands   	Pad
111	Faktory Klash   	Pad
112	Gutterall Sweep 	Pad
113	Fazoids         	Pad
114	Crazy Burst     	Pad
115	Tonky Honk Piano	Pad
116	Scared Ambience 	Pad
117	Sticky Lead     	Lead
118	Hard Pad        	Pad
119	M1 Goodness     	Pad
120	Nippon Clash    	Pad
121	Frog Blobs      	Pad
122	Skull Moog      	Pad
123	Clangorous Blip 	Pad
124	Gigantic Lead   	Lead
125	Aluminum Pad    	Pad
126	Vocal Organ     	Organ
127	Shelflife Pad   	Pad
128	Hi NRG Lead     	Lead


-------------------------------------------------
BANK F - Analoguesque Leftovers			
-------------------------------------------------
#	Patch Name      	Category
001	Wiry Lead       	Lead
002	Dreamsicle Pad  	Pad
003	In My Dream Pad 	Pad
004	Zany Bass       	Bass
005	Analog Cream Pad	Pad
006	Xylo Pad        	Pad
007	Analog Choir Pad	Pad
008	Andromeda Vibes 	Pad
009	Harsh Digi Lead 	Lead
010	Dream Keys      	Pad
011	Discord Lead    	Lead
012	Crystal Sweep   	Pad
013	Gutteral Pipes  	Pad
014	Analog Dream Pad	Pad
015	Iron Sweep Pad  	Pad
016	Ion Lead        	Lead
017	Blister Bass    	Bass
018	Digi Scrape Lead	Lead
019	Gameworld 101   	Fx
020	Caliber Keys    	Lead
021	Squashbox Lead  	Lead
022	Organ Swells    	Organ
023	Bouncy Balls Pad	Pad
024	Progressive Keys	Pad
025	Tyre Screech Pad	Pad
026	Smooth Kreem Pad	Pad
027	Noise Bop Pad   	Pad
028	Analog Str Bliss	Pad
029	Bellorganic Pad 	Organ
030	Thin Analog Pad 	Pad
031	Vibey Organ     	Organ
032	Crushroller FX  	Fx
033	Pluckee Pad     	Pad
034	Xylo Blips      	Pad
035	Tinsel Sweep Ld 	Lead
036	Metal Frog Pad  	Pad
037	Clarke Blips    	Pad
038	Rooftops Lead   	Lead
039	Cyber Vacuum Pad	Pad
040	Piazza Navona Ld	Lead
041	Rev Sweep Pad   	Pad
042	Vacuum Ghost Ld 	Lead
043	Crazed Mind Lead	Lead
044	CZ Resonance Pad	Pad
045	Incongruent Lead	Lead
046	Echo Blips Pad  	Pad
047	Mercury Horns   	Lead
048	Noisy Swoosh Pad	Pad
049	Majesty Pads    	Pad
050	DX Fallover Pad 	Pad
051	Horn Choir      	Pad
052	Erasure Keys    	Lead
053	Percussive Organ	Organ
054	Gnome Whip Pad  	Pad
055	In a Traanz Lead	Lead
056	Pulse Drops FX  	Fx
057	Esynth Keys     	Pad
058	Keystring Pad   	Pad
059	Discord Blips   	Pad
060	Formant Lead    	Lead
061	All Bells Pad   	Pad
062	SampleString Pad	Pad
063	Organic Woodwind	Pad
064	Moving Bell pad 	Pad
065	Wind Grind Pad  	Pad
066	Buzzcut Bass    	Bass
067	Alpha Sweep Pad 	Pad
068	Save Me Pad     	Pad
069	Vulcan Voices   	Pad
070	Bloopy Pad      	Pad
071	WhineBot Pad    	Pad
072	Wonky Bells     	Pad
073	Duck Pluck Pad  	Pad
074	Phat Pads       	Pad
075	Gamma Strings   	Pad
076	1985 Digi Pad   	Pad
077	More Plucking   	Lead
078	Weee Lead       	Lead
079	Blippity Blops  	Pad
080	AM Radio Lead   	Lead
081	Binge Sweep Pad 	Pad
082	Faraway Lands   	Pad
083	Zipper Strings  	Pad
084	Selfie lead     	Lead
085	Base Leads      	Lead
086	Thinswipe Lead  	Lead
087	Sampled Plunk   	Pad
088	Lead Me Astray  	Pad
089	Pluckhaven      	Pad
090	Vaal Strings    	Pad
091	Jolly Lead      	Lead
092	Toys R Them     	Pad
093	Blippety Bloops 	Pad
094	Zingy Organ     	Organ
095	Erasure Again   	Lead
096	Ringing Organ   	Organ
097	Choked Blips    	Pad
098	Mercuric Strings	Pad
099	Dirty Bells     	Pad
100	Blister Bowp    	Bass
101	Raspy Strings   	Pad
102	WhipleyGig      	Pad
103	Squigly Organ   	Organ
104	Coronary Lead   	Lead
105	Blaster Strings 	Pad
106	Inky Pad        	Pad
107	Tinkle Bells    	Pad
108	Faze Sweeper    	Pad
109	Muddy Strings   	Pad
110	Frog Burp       	Pad
111	Glass Whistler  	Pad
112	Broad Strings   	Pad
113	Undulating Str  	Pad
114	Orchestra Organ 	Organ
115	LoFi Strings    	Pad
116	Firefly Pad     	Pad
117	Sweeper Strings 	Pad
118	Log Bass        	Bass
119	Mega Str Lead   	Lead
120	Street Organ    	Organ
121	Shifting Sweep  	Pad
122	Clavi Synth     	Pad
123	Tremolo Pad     	Pad
124	Hellscapes      	Pad
125	WTH Trumpet     	Lead
126	Ambient Pad     	Pad
127	Aerie Lead      	Lead
128	Arcade Death    	Fx


-------------------------------------------------
BANK G - Analoguesque Serpentine Hydra			
-------------------------------------------------
#	Patch Name      	Category
001	Bass FM         	Bass
002	Buzzer Pad      	Pad
003	Smooth Pad      	Pad
004	Stringsound     	Pad
005	Trance Strings  	Pad
006	InterBass       	Bass
007	Chili Wobble    	Pad
008	Slick Lead      	Lead
009	Pad from Mars   	Pad
010	Crystal Castles 	Pad
011	Decimation      	Pad
012	Weird Warble    	Pad
013	Digicord        	Pad
014	Purgatory       	Pad
015	Glistening      	Pad
016	Digital Frets   	Pad
017	Factory Floor   	Pad
018	Funny Organ     	Organ
019	Decimitator     	Pad
020	Happy Organ     	Organ
021	Big Orch        	Pad
022	Bulbous Bass    	Bass
023	Percussive Organ	Organ
024	Glass FM Bass   	Bass
025	Undulation Pad  	Pad
026	Digital Orch Hit	Pad
027	Balsamic Organ  	Organ
028	Hurt Me         	Pad
029	Sideband Organ  	Organ
030	Glass Squares   	Pad
031	Sparkling Xylo  	Pad
032	Dirty Blips     	Pad
033	Ugly Organ      	Organ
034	Softcell Organ  	Organ
035	Striking Bass   	Bass
036	String Hits     	Pad
037	Out Of Order    	Pad
038	Fat Stringz     	Pad
039	Dainty Strings  	Pad
040	Rip Aurora      	Pad
041	Aluminum Guitar 	Pad
042	Ballzy Voices   	Pad
043	Dockyard Scrapes	Pad
044	Ye Old Organ    	Organ
045	Phasing Swirl   	Pad
046	Fading Strings  	Pad
047	Majestic Pipes  	Pad
048	Crying Strings  	Pad
049	Factory Ambience	Pad
050	Broken Strings  	Pad
051	Chorale Pad I   	Pad
052	Chorale Pad II  	Pad
053	Death Strings   	Pad
054	Pad from Venus  	Pad
055	Pluck Bass      	Bass
056	Ye Old Casio CZ 	Pad
057	Nominal Voices  	Pad
058	Strained Horizon	Pad
059	Bugout Voices   	Pad
060	Steroid R2D2    	Pad
061	Copper Chimes   	Pad
062	Prologue Bites  	Pad
063	Sandy Keys      	Pad
064	Digital Pipes   	Pad
065	The Woodwind    	Pad
066	Warped Keys     	Pad
067	Digi SquashBox  	Pad
068	Searing Lead    	Lead
069	More Trance     	Lead
070	Music Box       	Pad
071	String Pads     	Pad
072	Sampler Keys    	Pad
073	CZ ish          	Pad
074	Airy Choir      	Pad
075	Clubbed Keys    	Pad
076	Screaming Lead  	Lead
077	Bulby Noise     	Pad
078	Wheezing Pad    	Pad
079	Perc Woodwind   	Pad
080	Heavy Bass      	Bass
081	Soda Bottle     	Pad
082	Starry Lead     	Lead
083	Clavi Strings   	Pad
084	Background Str  	Pad
085	Pad from Pluto  	Pad
086	Choir Strings   	Pad
087	Xylo Strings    	Pad
088	Ringer Pad      	Pad
089	Clark lead      	Lead
090	Complex Lead    	Lead
091	Glistening Str  	Pad
092	Clark Pro-1     	Pad
093	Glass Woodwind  	Pad
094	Digital Fart    	Pad
095	Wowzers         	Pad
096	Ring Percussion 	Pad
097	Cozy Pad        	Pad
098	Flutesque       	Pad
099	Heated Pad      	Pad
100	Roland Wowzers  	Pad
101	Simple Lead     	Lead
102	Shining Pad     	Pad
103	Come 2 Get U    	Pad
104	Hurt Me         	Pad
105	Chinese Bells   	Pad
106	Sharp Blip      	Pad
107	Swirligig       	Pad
108	Melodic Lead    	Lead
109	Hit Me          	Pad
110	Ants Pad        	Pad
111	Truck Lead      	Lead
112	Blocky Lead     	Lead
113	Bronze Orch     	Pad
114	Muddy Wow       	Pad
115	Plucky Strings  	Pad
116	Biting Pad      	Pad
117	Wasteland       	Pad
118	Rumble Bass     	Bass
119	Artifact Bass   	Bass
120	Pearly Lead     	Lead
121	Neptune Voices  	Pad
122	Belgian Lead    	Lead
123	OuterSpace Choir	Pad
124	Woodu Pad       	Pad
125	Edgy Strings    	Pad
126	Sinewy Lead     	Lead
127	The Fullness    	Pad
128	Thicke Pads     	Pad


-------------------------------------------------
BANK H - Analoguesque Draconic Hydra			
-------------------------------------------------
#	Patch Name      	Category
001	Squarez         	Lead
002	Wheezing Lead   	Lead
003	Breezy Organ    	Organ
004	Yazoo Rez Bass  	Bass
005	Glassicles      	Pad
006	Italo Echos     	Pad
007	Royale Strings  	Pad
008	Vox Lead        	Lead
009	Sheet Metal     	Pad
010	Metal Slices    	Pad
011	Wonky Lead      	Lead
012	Red Cave Plops  	Pad
013	Skinny Rez Lead 	Lead
014	Happy Organ     	Organ
015	Tyre Screech    	Pad
016	Thin Bowp Bass  	Bass
017	Glass Sweep     	Pad
018	Magic Fly Lead 1	Lead
019	Boink Lead      	Lead
020	Screech Craptar 	Pad
021	Tinkly Organ    	Organ
022	Deep Strings    	Pad
023	What Are You    	Pad
024	Sinful Sines    	Pad
025	Saturn Bugs     	Pad
026	Smart Strings   	Pad
027	Crusher Bass    	Bass
028	Guitar Ha-Ha    	Lead
029	Blippy Rez Pad  	Pad
030	Proxima Lead    	Lead
031	Erasure Classic 	Pad
032	Gated Traanz    	Lead
033	Cavernous Organ 	Organ
034	Dirty Squarz    	Lead
035	Aliens Pad      	Pad
036	Vacuum Lead     	Lead
037	Clangorousity   	Pad
038	Sweep Organ     	Organ
039	Silken Strings  	Pad
040	Circus Arcade   	Pad
041	Buster Lead     	Lead
042	Melancholica    	Pad
043	Pluck World     	Pad
044	Alternating Lead	Lead
045	Dirty Sweep     	Pad
046	Old Bowl        	Pad
047	Reverse Sweeper 	Pad
048	All Over Bells  	Pad
049	Bamboo Sweep    	Pad
050	Electric Leaf   	Pad
051	Warp Drive      	Pad
052	Strangled Bells 	Pad
053	Broken Mandolin 	Pad
054	Centauri Strings	Pad
055	Ouija Board     	Pad
056	Clown Organ     	Organ
057	Drama Strings   	Pad
058	Whispy Echos    	Pad
059	Throaty Bass    	Bass
060	Violin Hit      	Pad
061	Keys Lead       	Lead
062	Casiotone World 	Pad
063	Ripping Wow     	Pad
064	Special Lead    	Lead
065	Back to 80s     	Pad
066	Sinuous Sweep   	Pad
067	Heavenly Str    	Pad
068	Broken Synth    	Pad
069	Flutish Lead    	Lead
070	Swirlishness    	Pad
071	Synth Talkies   	Pad
072	Movie Lead      	Lead
073	Flute Slap      	Pad
074	King Strings    	Pad
075	Rubber Sweep    	Pad
076	Fazoid Strings  	Pad
077	Talkies Lead    	Lead
078	Feedback Blips  	Pad
079	Sampler Hit     	Pad
080	Squeeze Me Lead 	Lead
081	Wonkated Organ  	Organ
082	Echo Saws       	Pad
083	Adult Music Box 	Pad
084	Compleks Strings	Pad
085	Broken World    	Pad
086	Call Out        	Pad
087	8-Bit Synth     	Pad
088	Ozonisphere Str 	Pad
089	Whispy Whine    	Pad
090	Earsplit Lead   	Lead
091	StringCasio     	Pad
092	Eastern Drone   	Pad
093	Classic Digi    	Pad
094	Magic Fly Lead 2	Lead
095	Crap Leads      	Lead
096	Grungy Pluck    	Pad
097	Sweeper Bass    	Bass
098	UFO Lead        	Lead
099	Mario Organ     	Organ
100	Square Mono     	Lead
101	Groaning Strings	Pad
102	Welp Organ      	Organ
103	Spectral Lead   	Lead
104	Analog Digi     	Pad
105	50s Radio Mess  	Pad
106	Big Synthi Lead 	Lead
107	Sampler Keys    	Pad
108	Muddy Lead      	Lead
109	OtherSide Of Luv	Pad
110	Heavy Drone     	Pad
111	Vintage Organ   	Organ
112	Wake Up Lead    	Lead
113	Measly Pluck    	Pad
114	Coffin Strings  	Pad
115	DM Organ        	Organ
116	Stringish       	Pad
117	Yazoo Leads     	Lead
118	Rusty Nails     	Pad
119	Farout Lead     	Lead
120	Samplevision    	Pad
121	Burned Strings  	Pad
122	Compleks Lead   	Lead
123	SynthKey Strings	Pad
124	Bleeding Strings	Pad
125	Gliss Lead      	Lead
126	Jonny Mary Bass 	Bass
127	Jonny Mary Gtr  	Lead
128	Jonny Mary PW   	Lead
