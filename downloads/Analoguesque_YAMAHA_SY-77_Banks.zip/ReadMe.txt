----------------------------------------------------------------------------------------------------------------------------------
NOTICE

All banks, samples, or presets are copyright(c) 2001 Ian Wilson, unless otherwise noted. They are provided free to use, but
cannot be sold under any circumstances (for profit, loss, or break-even) without the express permission of the copyright 
owner, Ian Wilson (thewilsonsusa@gmail.com).
----------------------------------------------------------------------------------------------------------------------------------

As is tradition with all Analoguesque sounds, our Yamaha SY77 preset banks are designed to enhance the analog capabilities of this synth to the max. 
Our presets expose some serious hidden talent in the SY77, and push it to the limit of it's potential as a monster synth. The SY77 reaches a 
pinnacle in these presets, with amazingly full and phatt analog sounds, and with a special kind of grittiness that only the SY77 can achieve. It 
does things even analog synths would cry about!� The SY77 patches are for loading into a Yamaha SY77 or TG77, and are provided in standard Sysex 
and Midi format 0, since the TG77 does not have a floppy drive, and the drives on the SY77 are notoriously problematic.

Few people know the power of the SY77, and those that do will tell you never to pass up on the chance to use this beast. This synth has the 
oscillator-layering capabilities of a monster, and can create some huge sounds! Unfortunately, most sound banks out there for the SY77 are 
straight conversions from old DX7 patch banks, so the true power of the SY77 is never explored. Furthermore, many banks specifically created for 
the SY77 were done at a time when the analog sound was laughed at, so they usually consist of attempts to recreate acoustic sounds. The difference 
between a DX synth and the SY77 is stark when you take into account all the added complexity of the SY77. To truly get the full potential of this 
synth, sounds must be designed specifically on and for the SY77, and that's what we have done.

Each of our SY77 banks contains 64 presets, all taking full advantage of the hidden and highly underrated talents of the Yamaha SY77. The ability 
to be a monster synth is there, and our sound banks have finally let this monster loose and allowed it to reach its potential, with heavily layered 
and phatt analog sounds, thumping basses, amazing rez sweeps, distorted and grungy leads, and many other sounds only the SY77 is capable of.

We presently have three banks of 64 presets available:

----------------------------------
Analog Dreams / Alternate
----------------------------------
64 presets of amazing analog emulations, with a few digital sounds thrown in. This set has a bonus alternative bank, which contains another 64 presets 
of variations on the Analog Dreams bank. Some of the patches in this alternative bank are different enough to be regarded as new sounds. That's 128 
patches in all!� Lots of seering analog leads, sweeps, pads, and basses! We have not heard any banks available for the SY77 which sound so close to 
analog! Hours and hours were spent perfecting each sound, and making sure we took full advantage of what the SY77 synthesis engine has to offer. If 
you're looking for some analog spice to brighten up your SY77 life, you are definitely in the right place. These patches will do it for you!

----------------------------------
Digital Vortex
----------------------------------
Another 64 presets of grungy vintage patches, with a harder edge and a more defined sound. This bank will appeal to those interested in a little 
more grittiness to their vintage sounds. More synth leads and super rez sweeps, heavy basses and shimmering pads ... the works! Again, a lot of 
effort was put into these patches to ensure that we maxed out the analog-like features of the SY77. You've never heard a non-virtual, digital synth 
sound so analog. The raw sound of this bank makes some of these patches are really, really phatt!

----------------------------------
Plastikation
----------------------------------
Yet another 64 presets of supreme vintage sounds, filling every gap possibly left by Analog Dreams and Digital Vortex. Once again this bank contains 
64 analog synth sounds of the utmost quality. We just can't get enough of these sounds, so here are another 64 of them. Some of the pads, leads and 
basses in this bank are unbelievable - you just can't believe this is a digital synth, never mind an FM synth!